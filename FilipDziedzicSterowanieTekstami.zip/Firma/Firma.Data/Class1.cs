﻿namespace Firma.Data
{
    public class Class1
    {

    }
}
